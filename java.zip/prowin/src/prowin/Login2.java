package prowin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Login2 extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField txt_un;
	private JPasswordField pf;
	ResultSet rs;
	Connection con;
	Statement stmt;
	String tun,tpf,un,pw;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login2 frame = new Login2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 485, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(94, 121, 101, 29);
		contentPane.add(lblNewLabel);
		
		txt_un = new JTextField();
		txt_un.setBounds(189, 122, 178, 29);
		contentPane.add(txt_un);
		txt_un.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(94, 178, 101, 29);
		contentPane.add(lblNewLabel_1);
		
		pf = new JPasswordField();
		pf.setBounds(187, 179, 180, 29);
		contentPane.add(pf);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnNewButton.setBounds(112, 235, 117, 29);
		btnNewButton.addActionListener(this);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnNewButton_1.setBounds(244, 235, 123, 29);
		btnNewButton_1.addActionListener(this);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Receipe Book        Login");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_2.setBounds(129, 96, 238, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\pruth\\Desktop\\loginrecepe.jpg"));
		lblNewLabel_3.setBounds(0, 10, 471, 323);
		contentPane.add(lblNewLabel_3);
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","");
			stmt=con.createStatement();
		}
		catch(Exception e1){
			System.out.println(e1);
	}
}
	public void actionPerformed(ActionEvent e) {
		try {
			String cmd=e.getActionCommand();
			if(cmd.equals("Submit"))
			{
				tun=txt_un.getText();
				tpf=pf.getText();
				rs=stmt.executeQuery("select* from login");
				if(rs.next())
				{
					un=rs.getString("Username");
					pw=rs.getString("Password");
					if(tun.equals(un) && tpf.equals(pw))
					{
						WelcomePage wp=new WelcomePage();
						wp.show();
					}
					else
						JOptionPane.showMessageDialog(null, "Invalid Username and Password");
				}
			}
			
		}
		catch(Exception e2) {
			System.out.println(e2);
		}
	}
}

